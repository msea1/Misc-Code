local laptopScreen = "Built-in Retina Display"
local leftMonitor = "DELL U2719D (1)"
local centerMonitor = "DELL U2719D (2)"
local rightMonitor = "DELL U2518D"

-- Define position values that don't exist by default in hs.layout.*
local positions = {
  leftTop = {x=0, y=0, w=0.5, h=0.5},
  leftBottom = {x=0, y=0.5, w=0.5, h=0.5},
  rightTop = {x=0.5, y=0, w=0.5, h=0.5},
  rightBottom = {x=0.5, y=0.5, w=0.5, h=0.5}
}

local layoutQuadScreen = {
  {"iTerm2", nil, rightMonitor, {x=0, y=0, w=0.4, h=1}, nil, nil},
}

local layoutSingleScreen = {
  {"iTerm2", nil, rightMonitor, {x=0, y=0, w=1, h=1}, nil, nil},
}

local appNames = {
  "iTerm2",
}


local function idDisplays()
  for k,v in pairs(hs.screen.allScreens()) do
    x, y = v:position()

    if x == 0 and y ==0 then
        laptopScreen = v
    elseif x == 0 then
        leftMonitor = v
    elseif x == 1 then
      rightMonitor = v
    else
      centerMonitor = v
    end
  end
end


--[[
  hs.screen.watcher.new(function()
    if num_of_screens ~= #hs.screen.allScreens() then
      autolayout.autoLayout()
      num_of_screens = #hs.screen.allScreens()
    end
  end):start()
  ]]

local function launchApps()
  for i, appName in ipairs(appNames) do
    hs.application.launchOrFocus(appName)
  end
end

local menu = hs.menubar.new()

local function setSingleScreen()
  menu:setTitle("🖥1")
  menu:setTooltip("Laptop Layout")
  hs.layout.apply(layoutSingleScreen)
end

local function setQuadScreen()
  menu:setTitle("🖥4")
  menu:setTooltip("Quad Screen Layout")
  hs.layout.apply(layoutQuadScreen)
end

local function setTest()
  idDisplays()
  if (hs.application.get("iTerm2") == nil) then
        print('Application iTerm2 not found')
        return
  end
  hs.layout.apply{{"iTerm2", null, laptopScreen, hs.layout.maximized, nil, nil}}
end


local function enableMenu()
  menu:setTitle("🖥")
  menu:setTooltip("No Layout")
  menu:setMenu({
      { title = "Launch Apps", fn = launchApps },
      { title = "Set Office Layout", fn = setQuadScreen },
      { title = "Set Laptop Layout", fn = setSingleScreen },
      { title = "Test", fn = setTest },
  })
end

enableMenu()
hs.application.enableSpotlightForNameSearches(true)

